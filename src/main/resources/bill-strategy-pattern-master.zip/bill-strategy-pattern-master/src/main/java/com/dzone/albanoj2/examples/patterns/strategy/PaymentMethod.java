package com.dzone.albanoj2.examples.patterns.strategy;

public interface PaymentMethod {

	public void pay(int cents);
}
